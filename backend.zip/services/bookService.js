import * as bookModel from '../models/bookModel.js';

export const felchAllBooks = async () => {
  const books = await bookModel.fetch();
  return books;
}

export const createbook = async (book) => {
  const bookId = await bookModel.insert(book);
  return bookId;
}