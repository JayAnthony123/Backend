import express from "express";
import bookRoutes from './routes/bookRoute.js';
import bookRoutes from './routes/studentRoute.js';


//create express app
const app = express();

app.use('/book', bookRoutes);
app.use('/student', studentRoutes);


try {
  const port = 3000;
  app.listen(port, () => {
    console.log(`listening to part $(port)...`);
  })
} catch (e) {
  console.log(e);
}