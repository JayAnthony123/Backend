import pool from '../config/db.js';

//read 
export const fetch = async () => {
  const [rows] = await pool.query("SELECT * FROM book");
  return rows;
};

//insert 
export const fetch = async (book) => {
  const [rows] = await pool.query(
    "INSERT INTO book(name, authr) VALUES (?,?)",
    [book.name, book.author]
  );
  
  return result.inserrId;
}