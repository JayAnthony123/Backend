import * as bookController from '..bookControllers/bookcontroller.js';
import express from "express";

const bookRoutes = express.Router();

bookRoutes.get('/all', bookController.fetchAllBooks);
bookRoutes.post('/', bookController.fetchAllBooks);

export default bookRoutes;